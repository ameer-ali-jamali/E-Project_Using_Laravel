<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Connection Lost</title>
        <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.1.1/css/all.css">
    </head>

    <body style="background-color: bisque">
        <center>
            <div>
                <h4><i class="fas fa-database"></i> &nbsp;Database Connection Error</h4>
                <h3><i class="fas fa-server"></i> &nbsp;Local Host Or Server Not Foud !</h3>
                <h2><i class="fas fa-server"></i> &nbsp;Please Connect Local Host Or Server !!</h2>
                <h1><i class="fas fa-server"></i> &nbsp;No connection could be made because the target machine actively
                    refused it in</h1>
            </div>
        </center>
    </body>

</html>
<?php /**PATH C:\wamp\www\Github\project\resources\views/serverErrorMessage.blade.php ENDPATH**/ ?>